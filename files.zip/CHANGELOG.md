# Program STB — modificări (10.08.2026)

## Ce se urcă pe GitHub

| fișier | stare | obligatoriu |
|---|---|---|
| `index.html` | **modificat** | DA |
| `sw.js` | **modificat** | DA |
| `manifest.json` | neschimbat | nu |
| `db.json` | neschimbat | nu |

`Icons/`, `README.md`, `prezentare-stb.html` rămân exact cum sunt.

---

## Cum verifici că a mers

1. Urcă `index.html` și `sw.js` (Add file → Upload files → Commit).
2. Așteaptă ~1 minut să se termine deployment-ul GitHub Pages.
3. Deschide `https://gully892005-spec.github.io/ProgramSTB/`
4. **Important:** service worker-ul vechi ține versiunea veche în cache. Prima
   deschidere poate arăta încă vechiul cod — închide complet aplicația și
   redeschide-o. Pe telefon, dacă e instalată ca aplicație, închide-o din
   lista de aplicații recente. Alternativ: Ctrl+Shift+R pe desktop.
5. Am urcat cache-ul la `stb-2026-v8`, deci actualizarea se face singură.

### Verificări rapide după urcare

- [ ] Se deschide și arată tura de azi
- [ ] Tab-ul **Statistici** — apare secțiunea nouă **„Pe linii"**
- [ ] Butonul nou **💾** din bara de sus deschide Backup & restaurare
- [ ] Salvarea unei zile e instantanee (înainte era o mică pauză)
- [ ] Modul avion → aplicația încă arată indicatoarele (cache local)
- [ ] Chat-ul funcționează, butonul **Ban** răspunde (doar admin)
- [ ] Raportul PDF arată orele corecte pentru schimbul tău

Dacă ceva nu merge, spune-mi ce ecran și ce vezi — am fișierele exact în
starea asta și pot reveni punctual.

---

## Buguri reparate

### Critice

1. **XSS în chat** — mesajele, numele și depoul intrau direct în pagină.
   Oricine putea trimite cod care rula în aplicația tuturor celorlalți.
2. **Butonul Ban nu funcționa** — o acoladă în plus rupea `onclick`-ul.
3. **Offline rămâneai fără indicatori** — `db.json` se citea doar de pe
   GitHub, fără copie locală. Acum: repo local → GitHub → ultima copie salvată.
4. **Buclă infinită de retry** — la orice eroare de afișare, aplicația
   reîncerca de 3 ori pe secundă la nesfârșit. Telefon încins, baterie
   consumată, interfață blocată. Acum maxim 2 reîncercări.

### Funcționale

5. `TODAY` era înghețat la pornire — aplicația lăsată deschisă peste noapte
   rămânea pe ziua de ieri.
6. Zilele de **fracție** nu erau numărate deloc în tab-ul Statistici.
7. Graficul **„pe linii"** era mereu gol (citea un câmp inexistent), iar
   secțiunea nici măcar nu era afișată.
8. **Sărbătoare lucrată** — orele se pierdeau din statistici.
9. **Titan** raporta greșit „plecare din depou" (lipsea dintr-o listă).
10. Setarea reminder **dimineață/seară** era ignorată de service worker.
11. Reminderele se programau înainte să se încarce `db.json` → listă goală.
12. **Iconițele notificărilor** erau 404 (`/icon-192.png` în loc de
    `/Icons/icon-192.png`), 9 locuri. Lipseau și iconițele de home screen.
13. **„Șterge toate datele"** nu golea celelalte depouri din memorie.
14. **Importul** suprascria în tăcere datele altui depou.
15. Notificarea de seară se rata dacă nu erai fix la minutul 21:00.
16. Chei `p2026_alerted_*` se adunau la infinit în localStorage.
17. **Zi introdusă manual doar cu orele** (fără linie/tur) se pierdea complet
    — cazul normal la autobuze/troleibuze/Alexandria/București Noi.
    În test: 212h raportate ca 4h.
18. **Raportul PDF** tipărea orele de schimb 2 pentru toată lumea
    (citea un câmp care nu exista).
19. **Ecranul de Backup era inaccesibil** — funcția exista, dar niciun buton
    nu o apela. Acum are buton 💾.
20. **Scurgere de memorie în chat** — listener-ul de prezență online nu se
    oprea niciodată; fiecare deschidere lăsa în urmă încă unul activ.

---

## Curățenie de cod

Nu existau funcții identice, dar același bloc de logică era copiat în ~19
locuri, fiecare cu mici diferențe — de acolo veneau cifrele care nu se
potriveau între ecrane.

- `ziInfo(a,l,z)` — o singură funcție care răspunde „ce s-a lucrat în ziua asta"
- `descriereZi(a,l,z)` — textul scurt (era copiat cuvânt cu cuvânt de 3 ori)
- `statsLuna(an,luna)` — **un singur motor de statistici**; înainte existau
  două implementări paralele care dădeau rezultate diferite
- lista de depouri, copiată de **25 de ori** → `isDepotS1()`
- eliminate aliasurile `exportData`/`importData`/`selReminderTime` și cod mort

---

## Performanță

Măsurat cu 730 de zile completate (≈2 ani de folosire):

| operație | înainte | după |
|---|---|---|
| **salvare zi** | 20,3 ms | **4,4 ms** |
| bara cu luni (`rTabs`) | 14,3 ms | 1,1 ms |
| Statistici | 6,8 ms | 0,3 ms |
| Listă | 6,1 ms | 1,1 ms |
| Calendar | 2,5 ms | 0,5 ms |

Pe telefon înmulțește cu 5–10: salvarea unei zile trecea de 100–200 ms
(acea „înghețare" scurtă), acum e sub 25 ms.

Ce s-a schimbat: `rTabs` scana toate cheile salvate o dată pentru fiecare din
cele 120 de luni (~88.000 comparații); statisticile se recalculau de la zero
pentru fiecare ecran; numărătoarea de CO parcurgea 3.600 de zile. Acum toate
au cache invalidat automat la salvare. Inserările în DOM se fac grupat.
Timerele de 30 de secunde se opresc când aplicația e în fundal.

---

## De rezolvat separat (nu e cod)

**`AGENDA_CONTACTS` din `index.html`** conține ~87 de nume complete și numere
de telefon personale, într-un repo public. Nu am atins-o — e decizia ta. Dar
e o problemă reală de confidențialitate, iar istoricul git păstrează datele
chiar dacă le ștergi acum. Opțiuni: repo privat, rescrierea istoricului, sau
mutarea listei în Firestore cu acces autentificat.

---

## Urmează

Notificări push reale (FCM). Am nevoie de la tine:
1. Planul Firebase — Blaze sau nu (Cloud Functions programate cer Blaze)
2. Cheia VAPID — Firebase Console → Project Settings → Cloud Messaging
3. Ce colecții ai deja în Firestore
